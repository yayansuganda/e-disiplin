<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['pegawai.update', $model->nip] : 'pegawai.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Nip</label>
            <div class="col-md-6">
                <?php echo Form::text('nip',null, ['class' => 'form-control', 'id'=>'nip']); ?>

            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Nama Lengkap</label>
            <div class="col-md-6">
                <?php echo Form::text('nama_pegawai',null, ['class' => 'form-control', 'id'=>'nama_pegawai']); ?>

            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Tempat/Tanggal Lahir</label>
            <div class="col-md-6">
                <div class="row row-space-6">
                    <div class="col-6">
                        <?php echo Form::select('tempat_lahir',$tempat_lahir,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'tempat_lahir']); ?>

                    </div>

                    <div class="col-6">
                        <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                            <?php echo Form::text('tanggal_lahir',null, ['class' => 'form-control', 'placeholder'=>'Select Date', 'id'=>'tanggal_lahir']); ?>

                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Status Pernikahan</label>
            <div class="col-md-6">
                <?php echo Form::text('status_pernikahan',null, ['class' => 'form-control', 'id'=>'status_pernikahan']); ?>

            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Agama</label>
            <div class="col-md-6">
                <?php echo Form::text('agama',null, ['class' => 'form-control', 'id'=>'agama']); ?>

            </div>
        </div>

        <div class="form-group row m-b-15">
            <label class="col-md-3 text-md-right col-form-label">Alamat</label>
            <div class="col-md-6">
                <?php echo Form::textarea('alamat',null, ['class' => 'form-control', 'id'=>'alamat', 'rows'=>'2']); ?>

            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Jenis Kelamin</label>
            <div class="col-md-9">
                <div class="form-check form-check-inline">
                    <?php echo Form::radio('jenis_kelamin', 'laki-laki', true ); ?>

                    <label class="form-check-label" for="defaultInlineRadio1">Laki-Laki</label>
                </div>
                <div class="form-check form-check-inline">
                        <?php echo Form::radio('jenis_kelamin', 'perempuan', false ); ?>

                    <label class="form-check-label" for="defaultInlineRadio2">Perempuan</label>
                </div>
            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">Jenis Dokumen</label>
            <div class="col-md-6">
                <div class="row row-space-6">
                    <div class="col-4">
                        <?php echo Form::text('jenis_dokument',null, ['class' => 'form-control', 'placeholder'=>'Jenis Dokument', 'id'=>'jenis_dokument']); ?>

                    </div>

                    <label class="col-md-2 text-md-right col-form-label">Nomor</label>
                    <div class="col-6">
                        <?php echo Form::text('nomor_dokument',null, ['class' => 'form-control', 'placeholder'=>'Select Date', 'id'=>'nomor_dokument']); ?>


                    </div>
                </div>
            </div>
        </div>

        <div class="form-group row m-b-10">
            <label class="col-md-3 text-md-right col-form-label">No. Hp</label>
            <div class="col-md-6">
                <div class="row row-space-6">
                    <div class="col-4">
                        <?php echo Form::text('nomor_hp',null, ['class' => 'form-control', 'placeholder'=>'Nomor Handphone', 'id'=>'nomor_hp']); ?>

                    </div>

                    <label class="col-md-2 text-md-right col-form-label">No.Telp</label>
                    <div class="col-6">
                        <?php echo Form::text('nomor_telephone',null, ['class' => 'form-control', 'placeholder'=>'Nomor Telephone', 'id'=>'nomor_telephone']); ?>


                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php echo Form::close(); ?>


<script>

        $('.default-select2').css('width', '100%');
        $('.default-select2').select2({
            dropdownParent: $('#modal'),
            placeholder : "---Pilih---",
            allowClear: true
        });


    $('.date').datepicker();



</script>

<?php /**PATH /website/project_bkd/resources/views/t_views/t_pegawai/form.blade.php ENDPATH**/ ?>