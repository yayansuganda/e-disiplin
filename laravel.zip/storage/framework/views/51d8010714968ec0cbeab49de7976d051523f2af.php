<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['jabatan.update', $model->id_jabatan] : 'jabatan.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Pegawai</label>
                <div class="col-md-6">
                    <?php echo Form::select('nip',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Jenis Jabatan</label>
                <div class="col-md-6">
                    <?php echo Form::select('id_m_jenis_jabatan',$jenis_jabatan,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_jenis_jabatan']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Jabatan</label>
                <div class="col-md-6">
                    <?php echo Form::select('id_m_jabatan',$model->id_m_jabatan == '' ? [] : $nama_jabatan,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_jabatan']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">TMT Jabatan</label>
                <div class="col-6">
                    <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                        <?php echo Form::text('tmt_jabatan',null, ['class' => 'form-control', 'placeholder'=>'TMT Jabatan', 'id'=>'tmt_jabatan']); ?>

                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Instansi Kerja</label>
                <div class="col-md-6">
                    <?php echo Form::text('instansi_kerja',null, ['class' => 'form-control', 'id'=>'instansi_kerja']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Unit Organisasi</label>
                <div class="col-md-6">
                    <?php echo Form::text('unit_organisasi',null, ['class' => 'form-control', 'id'=>'unit_organisasi']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nomor / Tanggal SK</label>
                <div class="col-md-6">
                    <div class="row row-space-6">
                        <div class="col-6">
                            <?php echo Form::text('nomor_sk',null, ['class' => 'form-control', 'placeholder'=>'Nomor SK', 'id'=>'nomor_sk']); ?>

                        </div>

                        <div class="col-6">
                            <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                                <?php echo Form::text('tanggal_sk',null, ['class' => 'form-control', 'placeholder'=>'Pilih Tanggal', 'id'=>'tanggal_lahir']); ?>

                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">TMT Pelantikan</label>
                <div class="col-6">
                    <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                        <?php echo Form::text('tmt_pelantikan',null, ['class' => 'form-control', 'placeholder'=>'TMT Pelantikan', 'id'=>'tmt_pelantikan']); ?>

                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
            </div>


        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
    $('.default-select2').css('width', '100%');
    $('.default-select2').select2({
        dropdownParent: $('#modal'),
        placeholder : "---Pilih---",
        allowClear: true
    });

    $('.date').datepicker();

    $(document).ready(function() {
        $('select[name="id_m_jenis_jabatan"]').on('change', function() {
            var stateID = $(this).val();
            console.log(stateID);
            if(stateID) {
                $.ajax({
                    url: '/m_jenis_jabatan/ajax/'+stateID,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('.default-select2').select2({
                        dropdownParent: $('#modal'),
                        placeholder : "---Pilih---",
                        allowClear: true
                        });
                        $('select[name="id_m_jabatan"]').empty();
                        $('select[name="id_m_jabatan"]').append('<option value="">--Pilih--</option>');
                        $.each(data, function(key, value) {
                            $('select[name="id_m_jabatan"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }else{
                $('select[name="nama_m_jabatan"]').empty();
            }
        });
    });

</script>

<?php /**PATH /website/project_bkd/resources/views/t_views/t_jabatan_pegawai/form.blade.php ENDPATH**/ ?>