<?php $__env->startSection('content'); ?>

<div id="content" class="content">

    <div class="form-group row m-b-10">
        <label class="col-md-1 text-md-right col-form-label">Pilih SKPD</label>
        <div class="col-md-9">
            <?php echo Form::select('id_m_skpd',$skpd,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_skpd']); ?>

        </div>

            <button id="reset" name="reset" class="col-md-2 btn btn-primary" type="submit"><i class="fe fe-search"></i>  Reset</button>

    </div>


    <div class="row ">

        <div class="col-md-6">
            <div id="container-pangkat-golongan"  >

            </div>
        </div>

        <div class="col-md-6">
            <div id="container-pendidikan"  ></div>
        </div>

        <div class="col-md-6">
            <br>
            <div id="container-eselonisasi"  ></div>
        </div>

        <div class="col-md-6">
            <br>
            <div id="container-jenis-jabatan"  ></div>
        </div>

        <div class="col-md-12">
            <br>
            <div id="container-skpd"  ></div>
        </div>
    </div>






</div>
<!-- end #content -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
// Radialize the colors
Highcharts.setOptions({
    colors: Highcharts.map(Highcharts.getOptions().colors, function (color) {
        return {
            radialGradient: {
                cx: 0.5,
                cy: 0.3,
                r: 0.7
            },
            stops: [
                [0, color],
                [1, Highcharts.Color(color).brighten(-0.3).get('rgb')] // darken
            ]
        };
    })
});



$('select[name="id_m_skpd"]').on('change', function() {
    var id = $(this).val();

    $.getJSON("<?php echo e(url('chart_filter/admin/')); ?>/"+id, function(data) {
    // Populate series

        var processed_series = new Array();
        $.each(data.chart_pangkat_golongan_terakhir, function(i, item) {
            processed_series.push(item.nama_pangkat);
        });

        function chart_PangkatGolongan() {
            var processed_data = new Array();
            $.each(data.chart_pangkat_golongan_terakhir, function(i, item) {
                processed_data.push({
                    name: item.nama_pangkat,
                    y: item.total,
                });
            });
        return processed_data;
        }


        function chart_Pendidikan() {
            var proses_pendidikan = new Array();

            $.each(data.chart_pendidikan, function(i, item) {
                proses_pendidikan.push({
                    name: item.nama_m_tingkat_pendidikan,
                    y: item.total,
                });
            });
        return proses_pendidikan;
        }


        function chart_Eselonisasi() {
            var proses_eselonisasi = new Array();

            $.each(data.chart_eselon, function(i, item) {
                proses_eselonisasi.push({
                    name: item.nama_m_eselon,
                    y: item.total,
                });
            });
        return proses_eselonisasi;
        }

        function chart_JenisJabatan() {
            var proses_jenis_jabatan = new Array();

            $.each(data.chart_jenis_jabatan, function(i, item) {
                proses_jenis_jabatan.push({
                    name: item.nama_m_jenis_jabatan,
                    y: item.total,
                });
            });
        return proses_jenis_jabatan;
        }


        Highcharts.chart('container-pangkat-golongan', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'bar'
            },
            title: {
                text: 'JUMLAH DATA BERDASARKAN PANGKAT GOLONGAN'
            },
            xAxis: {
                categories:  processed_series,
                title: {
                    text: null
                }
            },

            tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                enabled:false
            },

            credits: {
                enabled: false
            },
            series: [{

                    name: 'Jumlah',
                    colorByPoint: true,
                    data:  chart_PangkatGolongan()
                    }]
        });

        // Build the chart
        Highcharts.chart('container-pendidikan', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'JUMLAH PEGAWAI BERDASARKAN PENDIDIKAN'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.y} ',
                        connectorColor: 'silver'
                    }
                }
            },
            series: [{

                name: 'Jumlah',
                data:   chart_Pendidikan() ,


            }]
        });


        // Build the chart
        Highcharts.chart('container-eselonisasi', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'JUMLAH PEGAWAI BERDASARKAN ESELONISASI'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.y} ',
                        connectorColor: 'silver'
                    }
                }
            },
            series: [{

                name: 'Jumlah',
                data: chart_Eselonisasi()
            }]
        });



        // Build the chart
        Highcharts.chart('container-jenis-jabatan', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: 'JUMLAH PEGAWAI BERDASARKAN JENIS JABATAN'
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b>: {point.y} ',
                        connectorColor: 'silver'
                    }
                }
            },
            series: [{

                name: 'Jumlah',
                data: chart_JenisJabatan()
            }]
        });




    });
});













function Highcharts_skpd() {
    Highcharts.chart('container-skpd', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'column'
        },
        title: {
            text: 'JUMLAH DATA PEGAWAI BERDASARKAN SEMUA SKPD'
        },
        xAxis: {
            categories: [
                            <?php $__currentLoopData = $chart_skpd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            '<?php echo e($record->nama_m_skpd); ?>',
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
            title: {
                text: null
            }
        },

        tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        plotOptions: {
            bar: {
                dataLabels: {
                    enabled: true
                }
            }
        },
        legend: {
            enabled:false
        },

        credits: {
            enabled: false
        },
        scrollbar: {
            barBackgroundColor: 'gray',
            barBorderRadius: 7,
            barBorderWidth: 0,
            buttonBackgroundColor: 'gray',
            buttonBorderWidth: 0,
            buttonArrowColor: 'yellow',
            buttonBorderRadius: 7,
            rifleColor: 'yellow',
            trackBackgroundColor: 'white',
            trackBorderWidth: 1,
            trackBorderColor: 'silver',
            trackBorderRadius: 7
        },
        series: [{

                name: 'Jumlah',
                colorByPoint: true,
                data: [
                    <?php $__currentLoopData = $chart_skpd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($record->total); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                dataLabels: {
                enabled: true,
                rotation: -90,
                color: '#FFFFFF',
                align: 'right',
                format: '{point.y}', // one decimal
                y: -30, // 10 pixels down from the top
                style: {
                            fontSize: '13px',
                            fontFamily: 'Verdana, sans-serif'
                        }
                    }
                }]
    });
}





function Highcharts_PangkatGolongan() {
    Highcharts.chart('container-pangkat-golongan', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'bar'
        },
        title: {
            text: 'JUMLAH DATA BERDASARKAN PANGKAT GOLONGAN'
        },
        xAxis: {
            categories:  [
                            <?php $__currentLoopData = $chart_pangkat_golongan_terakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            '<?php echo e($record->nama_pangkat); ?>',
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        ],
            title: {
                text: null
            }
        },

        tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        plotOptions: {
            bar: {
                dataLabels: {
                    enabled: true
                }
            }
        },
        legend: {
            enabled:false
        },

        credits: {
            enabled: false
        },
        series: [{

                name: 'Jumlah',
                colorByPoint: true,
                data: [
                            <?php $__currentLoopData = $chart_pangkat_golongan_terakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            { name: '<?php echo e($record->nama_pangkat); ?>', y: <?php echo e($record->total); ?> },
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
                }]
    });
}



function Highcharts_Pendidikan() {
    Highcharts.chart('container-pendidikan', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'JUMLAH PEGAWAI BERDASARKAN PENDIDIKAN'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y} ',
                    connectorColor: 'silver'
                }
            }
        },
        series: [{

            name: 'Jumlah',
            data:   [
                        <?php $__currentLoopData = $chart_pendidikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        { name: '<?php echo e($record->nama_m_tingkat_pendidikan); ?>', y: <?php echo e($record->total); ?> },
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ] ,


        }]
    });
}


function Highcharts_Eselonisasi() {
    Highcharts.chart('container-eselonisasi', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'JUMLAH PEGAWAI BERDASARKAN ESELONISASI'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y} ',
                    connectorColor: 'silver'
                }
            }
        },
        series: [{

            name: 'Jumlah',
            data: [
                    <?php $__currentLoopData = $chart_eselon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { name: '<?php echo e($record->nama_m_eselon); ?>', y: <?php echo e($record->total); ?> },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
        }]
    });
}



function Highcharts_JenisJabatan() {
    Highcharts.chart('container-jenis-jabatan', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'JUMLAH PEGAWAI BERDASARKAN JENIS JABATAN'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y} ',
                    connectorColor: 'silver'
                }
            }
        },
        series: [{

            name: 'Jumlah',
            data: [
                    <?php $__currentLoopData = $chart_jenis_jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { name: '<?php echo e($record->nama_m_jenis_jabatan); ?>', y: <?php echo e($record->total); ?> },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ]
        }]
    });
}


Highcharts_skpd();
Highcharts_PangkatGolongan();
Highcharts_Pendidikan();
Highcharts_Eselonisasi();
Highcharts_JenisJabatan();


$('#reset').click(function(){
    $("#id_m_skpd").val('').trigger('change');
    Highcharts_skpd();
    Highcharts_PangkatGolongan();
    Highcharts_Pendidikan();
    Highcharts_Eselonisasi();
    Highcharts_JenisJabatan();
});

</script>

<?php $__env->stopPush(); ?>












<?php echo $__env->make('layouts.sidebar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /website/project_pakkaban/resources/views/dashboard/dashboard_admin.blade.php ENDPATH**/ ?>