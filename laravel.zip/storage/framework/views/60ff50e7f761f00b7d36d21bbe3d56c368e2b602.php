<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['diklat.update', $model->id_diklat] : 'diklat.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">



            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Pegawai</label>
                <div class="col-md-6">
                    <?php echo Form::select('nip',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Jenis Diklat</label>
                <div class="col-md-6">
                    <?php echo Form::select('id_m_jenis_diklat',$jenis_diklat,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_jenis_diklat']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Diklat</label>
                <div class="col-md-6">
                    <?php echo Form::text('nama_diklat',null, ['class' => 'form-control', 'id'=>'nama_diklat']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Tanggal Mulai</label>
                <div class="col-6">
                    <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                        <?php echo Form::text('tanggal_mulai',null, ['class' => 'form-control', 'placeholder'=>'Tanggal Mulai', 'id'=>'tanggal_mulai']); ?>

                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
            </div>


            <div class="form-group row m-b-10">
                    <label class="col-md-3 text-md-right col-form-label">Tanggal Selesai</label>
                    <div class="col-6">
                        <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                            <?php echo Form::text('tanggal_selesai',null, ['class' => 'form-control', 'placeholder'=>'Tanggal Selesai', 'id'=>'tanggal_selesai']); ?>

                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div>
                </div>

                <div class="form-group row m-b-10">
                    <label class="col-md-3 text-md-right col-form-label">Penyelenggara</label>
                    <div class="col-md-6">
                        <?php echo Form::text('penyelenggara',null, ['class' => 'form-control', 'id'=>'penyelenggara']); ?>

                    </div>
                </div>

            <div class="form-group row m-b-15">
                    <label class="col-md-3 text-md-right col-form-label">Alamat Diklat</label>
                    <div class="col-md-6">
                        <?php echo Form::textarea('alamat_diklat',null, ['class' => 'form-control', 'id'=>'alamat_diklat', 'rows'=>'2']); ?>

                    </div>
                </div>





        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
    $('.default-select2').css('width', '100%');
    $('.default-select2').select2({
        dropdownParent: $('#modal'),
        placeholder : "---Pilih---",
        allowClear: true
    });

    $('.date').datepicker();

</script>

<?php /**PATH /home/suganda/htdocs/project_bkd/resources/views/t_views/t_diklat_pegawai/form.blade.php ENDPATH**/ ?>