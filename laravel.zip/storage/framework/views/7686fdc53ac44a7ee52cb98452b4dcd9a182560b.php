<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['keluarga_kandung.update', $model->id_keluarga_kandung] : 'keluarga_kandung.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Pegawai</label>
                <div class="col-md-6">
                    <?php echo Form::select('nip',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Keluarga</label>
                <div class="col-md-6">
                    <?php echo Form::text('nama_keluarga',null, ['class' => 'form-control', 'id'=>'nama_keluarga']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Hubungan Keluarga</label>
                <div class="col-md-6">
                    <?php echo Form::select('id_m_hubungan_keluarga',$hubungan_keluarga,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_hubungan_keluarga']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Tempat Lahir</label>
                <div class="col-md-6">
                    <?php echo Form::select('tempat_lahir',$tempat_lahir,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'tempat_lahir']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Tanggal Lahir</label>
                <div class="col-6">
                    <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                        <?php echo Form::text('tanggal_lahir',null, ['class' => 'form-control', 'placeholder'=>'Tanggal Lahir', 'id'=>'tanggal_lahir']); ?>

                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Status Hidup</label>
                <div class="col-md-9">
                    <div class="form-check form-check-inline">
                        <?php echo Form::radio('status_hidup', 'Hidup', true ); ?>

                        <label class="form-check-label" for="defaultInlineRadio1">Hidup</label>
                    </div>
                    <div class="form-check form-check-inline">
                            <?php echo Form::radio('status_hidup', 'Meninggal', false ); ?>

                        <label class="form-check-label" for="defaultInlineRadio2">Meninggal</label>
                    </div>
                </div>
            </div>


        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
    $('.default-select2').css('width', '100%');
    $('.default-select2').select2({
        dropdownParent: $('#modal'),
        placeholder : "---Pilih---",
        allowClear: true
    });

    $('.date').datepicker();

</script>

<?php /**PATH /home/suganda/htdocs/project_bkd/resources/views/t_views/t_keluarga_kandung_pegawai/form.blade.php ENDPATH**/ ?>