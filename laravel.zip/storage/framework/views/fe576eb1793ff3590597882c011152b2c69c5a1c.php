<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['dp3.update', $model->id_dp3] : 'dp3.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">

        <div class="form-group row m-b-10">
                <label class="col-md-2 col-form-label">Tahun Penilaian</label>
                <div class="col-7">
                    <div class="input-group date datepicker-default"   data-date-format="yyyy" >
                        <?php echo Form::text('tahun_penilaian',null, ['class' => 'form-control', 'placeholder'=>'Tahun Penilaian', 'id'=>'tahun_penilaian']); ?>

                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
            </div>

        <div class="form-group row m-b-10">
            <label class="col-md-2 text-md-left col-form-label">Nama Pegawai</label>
            <div class="col-md-7">
                <?php echo Form::select('nip',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip']); ?>

            </div>
        </div>

        <div class="form-group row m-b-10">
            <div class="col-md-9">

                <ul class="nav nav-tabs">
                    <li class="nav-items">
                        <a href="#default-tab-1" data-toggle="tab" class="nav-link active">
                            <span class="d-sm-none">Tab 1</span>
                            <span class="d-sm-block d-none">Penilaian</span>
                        </a>
                    </li>
                    <li class="nav-items">
                        <a href="#default-tab-2" data-toggle="tab" class="nav-link">
                            <span class="d-sm-none">Tab 2</span>
                            <span class="d-sm-block d-none">Pejabat Penilai</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="#default-tab-3" data-toggle="tab" class="nav-link">
                            <span class="d-sm-none">Tab 3</span>
                            <span class="d-sm-block d-none">Atasan Pejabat Penilai</span>
                        </a>
                    </li>
                </ul>
                <!-- end nav-tabs -->
                <!-- begin tab-content -->
                <div class="tab-content">
                    <!-- begin tab-pane -->
                    <div class="tab-pane fade active show" id="default-tab-1">

                            <div class="form-group row m-b-10">
                                <div class="col-md-12">
                                    <div class="row row-space-6">

                                        <label class="col-md-3 text-md-right col-form-label">Kesetiaan</label>
                                        <div class="col-3">
                                            <?php echo Form::text('kesetiaan',null, ['class' => 'form-control', 'id'=>'kesetiaan']); ?>

                                        </div>

                                        <label class="col-md-3 text-md-right col-form-label">Prestasi Kerja</label>
                                        <div class="col-3">
                                                <?php echo Form::text('prestasi_kerja',null, ['class' => 'form-control', 'id'=>'prestasi_kerja']); ?>


                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="form-group row m-b-10">
                                    <div class="col-md-12">
                                        <div class="row row-space-6">

                                            <label class="col-md-3 text-md-right col-form-label">Tanggung Jawab</label>
                                            <div class="col-3">
                                                <?php echo Form::text('tanggung_jawab',null, ['class' => 'form-control', 'id'=>'tanggung_jawab']); ?>

                                            </div>

                                            <label class="col-md-3 text-md-right col-form-label">Ketaatan</label>
                                            <div class="col-3">
                                                    <?php echo Form::text('ketaatan',null, ['class' => 'form-control', 'id'=>'ketaatan']); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row m-b-10">
                                    <div class="col-md-12">
                                        <div class="row row-space-6">

                                            <label class="col-md-3 text-md-right col-form-label">Kejujuran</label>
                                            <div class="col-3">
                                                <?php echo Form::text('kejujuran',null, ['class' => 'form-control', 'id'=>'kejujuran']); ?>

                                            </div>

                                            <label class="col-md-3 text-md-right col-form-label">Kerjasama</label>
                                            <div class="col-3">
                                                    <?php echo Form::text('kerjasama',null, ['class' => 'form-control', 'id'=>'kerjasama']); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="form-group row m-b-10">
                                    <div class="col-md-12">
                                        <div class="row row-space-6">

                                            <label class="col-md-3 text-md-right col-form-label">Prakarsa</label>
                                            <div class="col-3">
                                                <?php echo Form::text('prakarsa',null, ['class' => 'form-control', 'id'=>'prakarsa']); ?>

                                            </div>

                                            <label class="col-md-3 text-md-right col-form-label">Kepemimpinan</label>
                                            <div class="col-3">
                                                    <?php echo Form::text('kepemimpinan',null, ['class' => 'form-control', 'id'=>'kepemimpinan']); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>


                    </div>
                    <!-- end tab-pane -->
                    <!-- begin tab-pane -->
                    <div class="tab-pane fade" id="default-tab-2">

                            <div class="form-group row m-b-10">
                                <label class="col-md-4 text-md-right col-form-label">Nama Pejabat Penilai</label>
                                <div class="col-md-7">
                                    <?php echo Form::select('nip_pp',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip_pp']); ?>

                                </div>
                            </div>

                            <div class="form-group row m-b-10">
                                <label class="col-md-4 text-md-right col-form-label">Jabatan Pejabat Penilai</label>
                                <div class="col-md-7">
                                    <?php echo Form::select('id_jabatan_pp',$model->id_jabatan_atasan_pp == '' ? [] : $jabatan_pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_jabatan_pp']); ?>

                                </div>
                            </div>

                            <div class="form-group row m-b-10">
                                <label class="col-md-4 text-md-right col-form-label">Golongan/Ruang</label>
                                <div class="col-md-7">
                                    <?php echo Form::select('id_m_ruang_golongan_pp',$model->id_m_ruang_golongan_pp == '' ? [] : $ruang_golongan,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_ruang_golongan_pp']); ?>

                                </div>
                            </div>

                            <div class="form-group row m-b-10">
                                <label class="col-md-4 text-md-right col-form-label">Pangkat</label>
                                <div class="col-md-7">
                                    <?php echo Form::select('id_m_jenis_pangkat_pp',$model->id_m_jenis_pangkat_pp == '' ? [] : $jenis_pangkat,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_jenis_pangkat_pp']); ?>

                                </div>
                            </div>

                    </div>
                    <!-- end tab-pane -->
                    <!-- begin tab-pane -->
                    <div class="tab-pane fade" id="default-tab-3">

                            <div class="form-group row m-b-10">
                                    <label class="col-md-4 text-md-right col-form-label">Nama Atasan Pejabat Penilai</label>
                                    <div class="col-md-7">
                                    <?php echo Form::select('nip_atasan_pp',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip_atasan_pp']); ?>


                                    </div>
                                </div>

                                <div class="form-group row m-b-10">
                                    <label class="col-md-4 text-md-right col-form-label">Jabatan Atasan Pejabat Penilai</label>
                                    <div class="col-md-7">
                                        <?php echo Form::select('id_jabatan_atasan_pp',$model->id_jabatan_atasan_pp == '' ? [] : $jabatan_pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_jabatan_atasan_pp']); ?>

                                    </div>
                                </div>

                                <div class="form-group row m-b-10">
                                    <label class="col-md-4 text-md-right col-form-label">Golongan/Ruang</label>
                                    <div class="col-md-7">
                                        <?php echo Form::select('id_m_ruang_golongan_atasan_pp',$model->id_m_ruang_golongan_atasan_pp == '' ? [] : $ruang_golongan,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_ruang_golongan_atasan_pp']); ?>

                                    </div>
                                </div>

                                <div class="form-group row m-b-10">
                                    <label class="col-md-4 text-md-right col-form-label">Pangkat</label>
                                    <div class="col-md-7">
                                        <?php echo Form::select('id_m_jenis_pangkat_atasan_pp',$model->id_m_jenis_pangkat_atasan_pp == '' ? [] : $jenis_pangkat,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_jenis_pangkat_atasan_pp']); ?>

                                    </div>
                                </div>


                    </div>
                    <!-- end tab-pane -->
                </div>



            </div>
        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
        $('.default-select2').css('width', '100%');
        $('.default-select2').select2({
            dropdownParent: $('#modal'),
            placeholder : "---Pilih---",
            allowClear: true
        });

        $('.date').datepicker({
            format: " yyyy",
            viewMode: "years",
            minViewMode: "years"
        });


    </script>






<?php /**PATH /home/suganda/htdocs/project_bkd/resources/views/t_views/t_dp3_pegawai/form.blade.php ENDPATH**/ ?>