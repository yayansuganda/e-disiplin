<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['pendidikan.update', $model->id_pendidikan_pegawai] : 'pendidikan.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">



            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Pegawai</label>
                <div class="col-md-6">
                    <?php echo Form::select('nip',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Tingkat Pendidikan</label>
                <div class="col-md-6">
                    <?php echo Form::select('id_m_tingkat_pendidikan',$tingkat_pendidikan,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_tingkat_pendidikan']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                    <label class="col-md-3 text-md-right col-form-label">Tahun Lulus</label>
                    <div class="col-6">
                        <div class="input-group date datepicker-default"   data-date-format="yyyy" >
                            <?php echo Form::text('tahun_lulus',null, ['class' => 'form-control', 'placeholder'=>'Tahun Lulus', 'id'=>'tahun_lulus']); ?>

                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                        </div>
                    </div>
                </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nomor Ijazah</label>
                <div class="col-md-6">
                        <?php echo Form::text('nomor_ijazah',null, ['class' => 'form-control', 'placeholder'=>'Nomor Ijazah', 'id'=>'nomor_ijazah']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Sekolah</label>
                <div class="col-md-6">
                        <?php echo Form::text('nama_sekolah',null, ['class' => 'form-control', 'placeholder'=>'Nama Sekolah', 'id'=>'nama_sekolah']); ?>

                </div>
            </div>


        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
    $('.default-select2').css('width', '100%');
    $('.default-select2').select2({
        dropdownParent: $('#modal'),
        placeholder : "---Pilih---",
        allowClear: true
    });

    $('.date').datepicker({
        format: " yyyy",
        viewMode: "years",
        minViewMode: "years"
    });


</script>

<?php /**PATH /home/suganda/htdocs/project_bkd/resources/views/t_views/t_pendidikan_pegawai/form.blade.php ENDPATH**/ ?>