<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['usulan_layanan_kenaikan_pangkat.update', $model->id_layanan_kenaikan_pangkat] : 'usulan_layanan_kenaikan_pangkat.store',
    'method'=> $model->exists ? 'PUT' : 'POST',
    'enctype' => 'multipart/form-data'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nomor Usulan</label>
                <div class="col-md-6">
                    <?php echo Form::text('nomor_usulan',null, ['class' => 'form-control', 'id'=>'nomor_usulan', 'readonly']); ?>

                </div>
            </div>


            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Pegawai</label>
                <div class="col-md-6">
                        <select id="nip" name="nip" class="default-select2 form-control">

                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data_pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data_pegawai->nip); ?>" <?php echo e($model->nip == $data_pegawai->nip  ? 'selected' : ''); ?>><?php echo e($data_pegawai->nip); ?> - <?php echo e($data_pegawai->gelar_depan); ?> <?php echo e($data_pegawai->nama_pegawai); ?>, <?php echo e($data_pegawai->gelar_belakang); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Golongan/Pangkat Terakhir</label>
                <div class="col-md-2">
                    <?php echo Form::text('nama_golongan_terakhir',null, ['class' => 'form-control', 'id'=>'nama_golongan_terakhir','readonly']); ?>

                </div>
                <div class="col-md-4">
                    <?php echo Form::text('nama_pangkat_terakhir',null, ['class' => 'form-control', 'id'=>'nama_pangkat_terakhir','readonly']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Foto Copy Karpeg</label>
                <div class="col-md-6">
                    <?php echo Form::file('path_karpeg',null, ['class' => 'form-control', 'id'=>'path_karpeg']); ?>

                </div>
            </div>



            <div class="form-group row m-b-10">
                    <label class="col-md-3 text-md-right col-form-label">Layanan Kenaikan Pangkat</label>
                    <div class="col-md-6">
                        <?php echo Form::select('id_m_layanan_kenaikan_pangkat',$layanan_kp,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_layanan_kenaikan_pangkat']); ?>

                    </div>
                </div>

                <div class="form-group row m-b-10">
                    <label class="col-md-3 text-md-right col-form-label">Pangkat/Golongan</label>
                    <div class="col-md-6">
                        <?php echo Form::select('id_m_pangkat_golongan',$pangkat_golongan,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'id_m_pangkat_golongan']); ?>

                    </div>
                </div>


            <div class="form-group row m-b-10">
                <div class="col-md-6">
                    <?php echo Form::text('status',null, ['class' => 'form-control', 'id'=>'status', 'hidden'=>true]); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <div class="col-md-6">
                    <?php echo Form::text('keterangan',null, ['class' => 'form-control', 'id'=>'keterangan', 'hidden'=>true]); ?>

                </div>
            </div>

        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
    $('.default-select2').css('width', '100%');
    $('.default-select2').select2({
        dropdownParent: $('#modal'),
        placeholder : "---Pilih---",
        allowClear: true
    });

    $('.date').datepicker();

</script>

<?php /**PATH /website/project_pakkaban/resources/views/t_views/t_usulan_pegawai/daftar_layanan_usulan/layanan_usulan_kp/form2.blade.php ENDPATH**/ ?>