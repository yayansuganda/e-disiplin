<?php echo Form::model($model,  [
    'route'=>$model->exists ? ['anak.update', $model->id_anak] : 'anak.store',
    'method'=> $model->exists ? 'PUT' : 'POST'
]); ?>



<div class="row">
    <div class="col-md-10 offset-md-2">

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Pegawai</label>
                <div class="col-md-6">
                    <?php echo Form::select('nip',$pegawai,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'nip']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Nama Anak</label>
                <div class="col-md-6">
                    <?php echo Form::text('nama_anak',null, ['class' => 'form-control', 'id'=>'nama_anak']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Jenis Kelamin</label>
                <div class="col-md-9">
                    <div class="form-check form-check-inline">
                        <?php echo Form::radio('jenis_kelamin_anak', 'Laki-Laki', true ); ?>

                        <label class="form-check-label" for="defaultInlineRadio1">Laki-Laki</label>
                    </div>
                    <div class="form-check form-check-inline">
                            <?php echo Form::radio('jenis_kelamin_anak', 'Perempuan', false ); ?>

                        <label class="form-check-label" for="defaultInlineRadio2">Perempuan</label>
                    </div>
                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Tempat Lahir</label>
                <div class="col-md-6">
                    <?php echo Form::select('tempat_lahir_anak',$tempat_lahir,null,['placeholder'=>'Pilih','class' => 'form-control default-select2','id'=>'tempat_lahir_anak']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Tanggal Lahir</label>
                <div class="col-6">
                    <div class="input-group date datepicker-default"   data-date-format="dd-mm-yyyy" >
                        <?php echo Form::text('tanggal_lahir_anak',null, ['class' => 'form-control', 'placeholder'=>'Tanggal Lahir', 'id'=>'tanggal_lahir_anak']); ?>

                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Status Anak</label>
                <div class="col-md-6">
                    <?php echo Form::text('status_anak',null, ['class' => 'form-control', 'id'=>'status_anak']); ?>

                </div>
            </div>

            <div class="form-group row m-b-10">
                <label class="col-md-3 text-md-right col-form-label">Pekerjaan</label>
                <div class="col-md-6">
                    <?php echo Form::text('pekerjaan',null, ['class' => 'form-control', 'id'=>'pekerjaan']); ?>

                </div>
            </div>

        </div>



    </div>
</div>

<?php echo Form::close(); ?>


<script>
    $('.default-select2').css('width', '100%');
    $('.default-select2').select2({
        dropdownParent: $('#modal'),
        placeholder : "---Pilih---",
        allowClear: true
    });

    $('.date').datepicker();

</script>

<?php /**PATH /home/suganda/htdocs/project_bkd/resources/views/t_views/t_anak_pegawai/form.blade.php ENDPATH**/ ?>