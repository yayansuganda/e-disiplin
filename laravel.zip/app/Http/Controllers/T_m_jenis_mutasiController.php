<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class T_m_jenis_mutasiController extends Controller
{
    //
}
