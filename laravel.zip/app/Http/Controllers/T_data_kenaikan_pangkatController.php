<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class T_data_kenaikan_pangkatController extends Controller
{
    //
}
