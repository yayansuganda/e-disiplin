<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class T_m_jenis_pegawai extends Model
{
    //
}
