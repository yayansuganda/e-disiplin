
<embed type="application/pdf" src="{{url('storage/'.Request::segment(2).'/'.Request::segment(3))}}" width="100%" height="700px">
