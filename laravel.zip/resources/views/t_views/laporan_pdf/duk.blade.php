<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 12">
<meta name=Originator content="Microsoft Word 12">
<link rel=File-List href="RAHASIA_files/filelist.xml">
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>Windows User</o:Author>
  <o:LastAuthor>Windows User</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>25</o:TotalTime>
  <o:Created>2019-12-09T05:46:00Z</o:Created>
  <o:LastSaved>2019-12-09T05:46:00Z</o:LastSaved>
  <o:Pages>2</o:Pages>
  <o:Words>295</o:Words>
  <o:Characters>1686</o:Characters>
  <o:Lines>14</o:Lines>
  <o:Paragraphs>3</o:Paragraphs>
  <o:CharactersWithSpaces>1978</o:CharactersWithSpaces>
  <o:Version>12.00</o:Version>
 </o:DocumentProperties>
</xml><![endif]-->
<link rel=dataStoreItem href="RAHASIA_files/item0001.xml"
target="RAHASIA_files/props0002.xml">
<link rel=themeData href="RAHASIA_files/themedata.thmx">
<link rel=colorSchemeMapping href="RAHASIA_files/colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:SpellingState>Clean</w:SpellingState>
  <w:GrammarState>Clean</w:GrammarState>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>EN-US</w:LidThemeOther>
  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:DontVertAlignCellWithSp/>
   <w:DontBreakConstrainedForcedTables/>
   <w:DontVertAlignInTxbx/>
   <w:Word11KerningPairs/>
   <w:CachedColBalance/>
  </w:Compatibility>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="--"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"
  DefSemiHidden="true" DefQFormat="false" DefPriority="99"
  LatentStyleCount="267">
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>
  <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" Priority="10" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" Priority="11" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" Priority="22" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="59" SemiHidden="false"
   UnhideWhenUsed="false" Name="Table Grid"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:"Cambria Math";
	panose-1:2 4 5 3 5 4 6 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:roman;
	mso-font-pitch:variable;
	mso-font-signature:-536869121 1107305727 33554432 0 415 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin:0cm;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	mso-hyphenate:none;
	font-size:12.0pt;
	font-family:"Times New Roman","serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-language:ZH-CN;}
span.SpellE
	{mso-style-name:"";
	mso-spl-e:yes;}
span.GramE
	{mso-style-name:"";
	mso-gram-e:yes;}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:Calibri;
	mso-fareast-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
.MsoPapDefault
	{mso-style-type:export-only;
	margin-bottom:10.0pt;
	line-height:115%;}
@page Section1
	{size:612.1pt 1008.15pt;
	margin:72.0pt 72.0pt 72.0pt 72.0pt;
	mso-header-margin:36.0pt;
	mso-footer-margin:36.0pt;
	mso-paper-source:0;}
div.Section1
	{page:Section1;}
 /* List Definitions */
 @list l0
	{mso-list-id:56;
	mso-list-type:simple;
	mso-list-template-ids:56;
	mso-list-name:WW8Num56;}
@list l0:level1
	{mso-level-start-at:2;
	mso-level-tab-stop:36.0pt;
	mso-level-number-position:left;
	text-indent:-18.0pt;}
ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-qformat:yes;
	mso-style-parent:"";
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-para-margin-top:0cm;
	mso-para-margin-right:0cm;
	mso-para-margin-bottom:10.0pt;
	mso-para-margin-left:0cm;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
table.MsoTableGrid
	{mso-style-name:"Table Grid";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-priority:59;
	mso-style-unhide:no;
	border:solid black 1.0pt;
	mso-border-themecolor:text1;
	mso-border-alt:solid black .5pt;
	mso-border-themecolor:text1;
	mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
	mso-border-insideh:.5pt solid black;
	mso-border-insideh-themecolor:text1;
	mso-border-insidev:.5pt solid black;
	mso-border-insidev-themecolor:text1;
	mso-para-margin:0cm;
	mso-para-margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="6146"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=EN-US style='tab-interval:36.0pt'>

<div class=Section1>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=624
 style='width:467.8pt;margin-left:12.5pt;border-collapse:collapse;border:none;
 mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'>
  <td width=624 valign=top style='width:467.8pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-top:6.0pt;margin-right:0cm;
  margin-bottom:0cm;margin-left:297.1pt;margin-bottom:.0001pt;text-align:center;
  text-indent:-297.1pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>KEPUTUSAN
  {{$sk_hd->nama_keputusan}}<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-top:6.0pt;margin-right:0cm;
  margin-bottom:0cm;margin-left:297.1pt;margin-bottom:.0001pt;text-align:center;
  text-indent:-297.1pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=GramE><span style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>NOMOR
  :</span></span><span style='font-size:11.0pt;line-height:115%;font-family:
  "Arial","sans-serif"'> {{$sk_hd->nomor}}<o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-top:6.0pt;margin-right:0cm;
  margin-bottom:6.0pt;margin-left:297.1pt;text-align:center;text-indent:-297.1pt;
  line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span style='font-size:
  11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal align=center style='margin-top:6.0pt;margin-right:0cm;
  margin-bottom:0cm;margin-left:297.1pt;margin-bottom:.0001pt;text-align:center;
  text-indent:-297.1pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>DENGAN
  RAHMAT TUHAN YANG MAHA ESA <o:p></o:p></span></p>
  <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
  line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span style='font-size:
  11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=643
 style='width:17.0cm;margin-left:5.4pt;border-collapse:collapse;border:none;
 mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=85 valign=top style='width:64.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=PT-BR style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
  mso-ansi-language:PT-BR'>Membaca</span><span style='font-size:11.0pt;
  line-height:115%;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=22 valign=top style='width:16.55pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>1.<o:p></o:p></span></p>
  </td>
  <td width=514 valign=top style='width:385.75pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=PT-BR style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
  mso-ansi-language:PT-BR'>Laporan dari {{$sk_hd->laporan_dari_tanggal}} tanggal {{$sk_hd->laporan_sampai_tanggal}} tentang
  pelanggaran oleh sdr. {{$sk_hd->nama_pegawai}} NIP.
  {{$sk_hd->nip_pelanggar}} tanggal {{$sk_hd->tanggal_pelanggaran}}</span><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=85 valign=top style='width:64.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>

 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=85 valign=top style='width:64.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=SpellE><span style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>Menimbang</span></span><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=536 colspan=2 valign=top style='width:402.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify;line-height:
  115%;tab-stops:252.0pt 342.0pt 351.0pt'><span lang=PT-BR style='font-size:
  11.0pt;line-height:115%;font-family:"Arial","sans-serif";mso-ansi-language:
  PT-BR'>bahwa untuk kelancaran pemeriksaan terhadap Sdr.
  {{$sk_hd->nama_pegawai}} , atas dugaan pelanggaran disiplin terhadap Pasal {{$sk_hd->pasal_hd}}
  angka {{$sk_hd->angka_hd}} huruf {{$sk_hd->huruf_hd}} yang ancaman hukumannya berupa hukuman disiplin tingkat
  berat, perlu menetapkan keputusan tentang Pembebasan Sementara dari Tugas
  Jabatannya;</span><span style='font-size:11.0pt;line-height:115%;font-family:
  "Arial","sans-serif"'><o:p></o:p></span></p>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3'>
  <td width=85 valign=top style='width:64.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=SpellE><span style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>Mengingat</span></span><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=22 valign=top style='width:16.55pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>1.<o:p></o:p></span></p>
  </td>
  <td width=514 valign=top style='width:385.75pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify;line-height:
  115%;tab-stops:297.0pt 342.0pt 351.0pt'><span lang=SV style='font-size:11.0pt;
  line-height:115%;font-family:"Arial","sans-serif";mso-ansi-language:SV'>Undang-undang
  Nomor 8 tahun 1974 sebagaimana telah diubah dengan Undang-undang Nomor 43
  Tahun 1999;</span><span style='font-size:11.0pt;line-height:115%;font-family:
  "Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4'>
  <td width=85 valign=top style='width:64.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=22 valign=top style='width:16.55pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>2.<o:p></o:p></span></p>
  </td>
  <td width=514 valign=top style='width:385.75pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify;line-height:
  115%;tab-stops:297.0pt 342.0pt 351.0pt'><span lang=SV style='font-size:11.0pt;
  line-height:115%;font-family:"Arial","sans-serif";mso-ansi-language:SV'>Peraturan
  Pemerintah Nomor 53 Tahun 2010 tentang Disiplin Pegawai Negeri Sipil</span><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5;mso-yfti-lastrow:yes'>
  <td width=85 valign=top style='width:64.0pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.65pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=22 valign=top style='width:16.55pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'>3.<o:p></o:p></span></p>
  </td>
  <td width=514 valign=top style='width:385.75pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify;line-height:
  115%;tab-stops:297.0pt 342.0pt 351.0pt'><span lang=SV style='font-size:11.0pt;
  line-height:115%;font-family:"Arial","sans-serif";mso-ansi-language:SV'>Peraturan
  Kepala Badan Kepegawaian Negara Nomor 21 Tahun 2010 tentang Ketentuan
  Pelaksanaan Peraturan Pemerintah Nomor 53 Tahun 2010 tentang Disiplin Pegawai
  Negeri Sipil<o:p></o:p></span></p>
  </td>
 </tr>
</table>

<p class=MsoNormal style='margin-top:6.0pt;margin-right:0cm;margin-bottom:0cm;
margin-left:297.1pt;margin-bottom:.0001pt;text-indent:-297.1pt;line-height:
115%;tab-stops:297.0pt 342.0pt 351.0pt'><span style='font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='margin-left:297.0pt;text-align:center;
text-indent:-297.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='margin-left:297.0pt;text-align:center;
text-indent:-297.0pt;line-height:115%;tab-stops:297.0pt 342.0pt 351.0pt'><span
style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-top:6.0pt;text-align:justify;line-height:115%;
tab-stops:72.0pt 81.0pt 252.0pt 342.0pt 351.0pt'><span lang=SV
style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-ansi-language:SV'><o:p>&nbsp;</o:p></span></p>

<span lang=SV style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman";mso-ansi-language:SV;mso-fareast-language:
ZH-CN;mso-bidi-language:AR-SA'><br clear=all style='mso-special-character:line-break;
page-break-before:always'>
</span>

<p class=MsoNormal style='margin-bottom:10.0pt;line-height:115%;mso-hyphenate:
auto'><span lang=SV style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-ansi-language:SV'><o:p>&nbsp;</o:p></span></p>

<table class=MsoTableGrid border=0 cellspacing=0 cellpadding=0 width=614
 style='width:460.7pt;margin-left:5.4pt;border-collapse:collapse;border:none;
 mso-yfti-tbllook:1184;mso-padding-alt:0cm 5.4pt 0cm 5.4pt;mso-border-insideh:
 none;mso-border-insidev:none'>
 <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
  <td width=614 colspan=10 valign=top style='width:460.7pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
  tab-stops:72.0pt 81.0pt 252.0pt 342.0pt 351.0pt'><span lang=SV
  style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>MEMUTUSKAN<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:1'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Menetapkan</span><span style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=499 colspan=8 valign=top style='width:373.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:2'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>KESATU</span><span style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=499 colspan=8 valign=top style='width:373.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify;tab-stops:252.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Membebaskan sementara dari tugas jabatan Saudara :</span><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:3'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=SpellE><span style='font-size:11.0pt;font-family:"Arial","sans-serif"'>Mengingat</span></span><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=83 valign=top style='width:62.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=SpellE><span style='font-size:11.0pt;font-family:"Arial","sans-serif"'>Nama</span></span><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=28 valign=top style='width:21.25pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=387 colspan=6 valign=top style='width:290.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:4'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=83 valign=top style='width:62.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>NIP<o:p></o:p></span></p>
  </td>
  <td width=28 valign=top style='width:21.25pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>:<o:p></o:p></span></p>
  </td>
  <td width=387 colspan=6 valign=top style='width:290.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:5'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=83 valign=top style='width:62.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=SpellE><span style='font-size:11.0pt;font-family:"Arial","sans-serif"'>Pangkat</span></span><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=28 valign=top style='width:21.25pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=387 colspan=6 valign=top style='width:290.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:6'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=83 valign=top style='width:62.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  class=SpellE><span style='font-size:11.0pt;font-family:"Arial","sans-serif"'>Jabatan</span></span><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p></o:p></span></p>
  </td>
  <td width=28 valign=top style='width:21.25pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=387 colspan=6 valign=top style='width:290.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:7'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=83 valign=top style='width:62.1pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>Unit <span
  class=SpellE>Kerja</span><o:p></o:p></span></p>
  </td>
  <td width=28 valign=top style='width:21.25pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=387 colspan=6 valign=top style='width:290.6pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:8'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=499 colspan=8 valign=top style='width:373.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify'><span lang=SV
  style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Terhitung mulai tanggal ........................... sampai ditetapkannya keputusan
  hukuman disiplin, karena yang bersangkutan diduga melakukan perbuatan yang
  melanggar ketentuan Pasal ... angka .... huruf ..... Peraturan Pemerintah
  Nomor 53 Tahun 2010<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:9'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>KEDUA<o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=499 colspan=8 valign=top style='width:373.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;text-align:justify'><span lang=SV
  style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Selama menjalani pembebasan sementara dari tugas jabatannya sebagaimana
  tersebut pada Diktum KESATU, kepada Sdr. ...................... tersebut
  tetap diberikan hak-hak kepegawaiannya sesuai dengan peraturan
  perundang-undangan<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:10'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>KETIGA<o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=499 colspan=8 valign=top style='width:373.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt'><span lang=SV style='font-size:
  11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:SV'>Keputusan ini
  mulai berlaku pada tanggal ditetapkan<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:11'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'>KEEMPAT<o:p></o:p></span></p>
  </td>
  <td width=21 valign=top style='width:15.4pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=499 colspan=8 valign=top style='width:373.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt'><span lang=SV style='font-size:
  11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:SV'>Keputusan ini disampaikan
  kepada yang bersangkutan untuk diindahkan dan dilaksanakan sebagaimana
  mestinya<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:12'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=519 colspan=9 valign=top style='width:389.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:13'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=236 colspan=5 valign=top style='width:177.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Ditetapkan di Sumbawa Barat<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:14'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=113 colspan=3 valign=top style='width:3.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Pada Tanggal <o:p></o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=104 valign=top style='width:77.95pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:15'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=236 colspan=5 valign=top style='width:177.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
  tab-stops:297.0pt 342.0pt 351.0pt'><span lang=SV style='font-size:11.0pt;
  font-family:"Arial","sans-serif";mso-ansi-language:SV'>Atasan Langsung<o:p></o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:16'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=76 valign=top style='width:2.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=142 colspan=3 valign=top style='width:106.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:17'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=76 valign=top style='width:2.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=142 colspan=3 valign=top style='width:106.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:18'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=76 valign=top style='width:2.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>Nama<o:p></o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=142 colspan=3 valign=top style='width:106.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:19'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=76 valign=top style='width:2.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>NIP<o:p></o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'>:<o:p></o:p></span></p>
  </td>
  <td width=142 colspan=3 valign=top style='width:106.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:20'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=76 valign=top style='width:2.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=142 colspan=3 valign=top style='width:106.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <tr style='mso-yfti-irow:21;mso-yfti-lastrow:yes'>
  <td width=95 valign=top style='width:71.35pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  style='font-size:11.0pt;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=283 colspan=4 valign=top style='width:212.15pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=76 valign=top style='width:2.0cm;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=19 valign=top style='width:14.2pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
  <td width=142 colspan=3 valign=top style='width:106.3pt;padding:0cm 5.4pt 0cm 5.4pt'>
  <p class=MsoNormal style='margin-top:6.0pt;tab-stops:297.0pt 342.0pt 351.0pt'><span
  lang=SV style='font-size:11.0pt;font-family:"Arial","sans-serif";mso-ansi-language:
  SV'><o:p>&nbsp;</o:p></span></p>
  </td>
 </tr>
 <![if !supportMisalignedColumns]>
 <tr height=0>
  <td width=95 style='border:none'></td>
  <td width=20 style='border:none'></td>
  <td width=83 style='border:none'></td>
  <td width=28 style='border:none'></td>
  <td width=151 style='border:none'></td>
  <td width=76 style='border:none'></td>
  <td width=19 style='border:none'></td>
  <td width=19 style='border:none'></td>
  <td width=19 style='border:none'></td>
  <td width=104 style='border:none'></td>
 </tr>
 <![endif]>
</table>

<p class=MsoNormal style='margin-top:6.0pt;line-height:115%;tab-stops:72.0pt 81.0pt 252.0pt 342.0pt 351.0pt'><span
style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
line-height:115%;tab-stops:72.0pt 81.0pt 252.0pt 342.0pt 351.0pt'><span
lang=SV style='font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-ansi-language:SV'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='line-height:115%'><span style='font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='line-height:115%'><span style='font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

</div>

</body>

</html>
