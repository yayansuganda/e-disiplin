<div class="modal fade" id="modal" style="max-width:900px;margin:auto">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modal-title">Modal Dialog</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body" name="modal-body"  id="modal-body">


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" id="modal-btn-save"></button>
            </div>
        </div>
    </div>
</div>

