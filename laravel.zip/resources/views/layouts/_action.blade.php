<a href="{{$url_show}}" class="btn-show btn btn-icon btn-primary btn-secondary btn-sm" title="Detail: {{ $model->name }}"><i class="fa fa-eye"></i></button></a>
<a href="{{$url_edit}}" class="modal-show edit btn btn-icon btn-primary btn-sm" title=" Edit {{ $model2 }}"><i class="fa fa-edit"></i></button></a>
<a href="{{$url_destroy}}" class="btn-delete btn btn-icon btn-danger btn-sm" title="{{ $model->name }}"><i class="fa fa-trash"></i></i></button></a>
