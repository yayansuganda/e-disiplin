
<a href="{{$url_show}}" class="btn btn-xs btn-success modal-show" title="Buat Surat Panggilan">SP</a>
<a href="{{$url_show}}" class="btn btn-xs btn-success modal-show" title="Buat SK Hukuman Disiplin ">SK</a>
<a href="{{$url_show}}" class="btn btn-xs btn-success modal-show" title="Input Hukuman Disiplin">IH</a>
