<a href="{{$url_show}}" class="btn-show btn btn-icon btn-primary btn-secondary btn-sm" title="View Detail Bulanan Kehadiran"><i class="fa fa-eye"></i></button></a>
<a href="{{$url_download}}" class="btn btn-icon btn-primary btn-sm"><i class="fa fa-download"></i></button></a>
