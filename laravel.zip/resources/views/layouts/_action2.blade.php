<a href="{{$url_edit}}" class="modal-show edit btn btn-icon btn-primary btn-sm" title=" Edit {{ $model2 }}"><i class="fa fa-edit"></i></button></a>
<a href="{{$url_destroy}}" class="btn-delete btn btn-icon btn-danger btn-sm" title="{{ $model->name }}"><i class="fa fa-trash"></i></i></button></a>
